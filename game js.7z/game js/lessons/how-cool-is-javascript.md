## JavaScript!

Programming (or coding) is a way to give instructions to a computer. JavaScript is a type of language that allows you to write these instruction.

### JavaScript is the language of the internet.

You can code on any computer as long as it has a browser. You don't have to install any special programs.

### JavaScript is the most popular programming language.

This means that you can find lots of friends to write code with!

### Cats like JavaScript too.

![Cats doing JavaScript](https://github.com/maxogden/javascript-for-cats/blob/master/images/customers3.png)
[Photo by JavaScript for Cats](www.jsforcats.com)

## Characters of JavaScript

* Semi-colon and Quotes

![](https://community.devexpress.com/blogs/markmiller/Quote_1D185A33.png)

* Curly braces and Brackets

![](https://community.devexpress.com/blogs/markmiller/Brackets_688823C4.png)

* Dots

![](https://community.devexpress.com/blogs/markmiller/AngleBrackets_39E1F515.png)

* Parenthesis

![](https://community.devexpress.com/blogs/markmiller/90_73752AD9.png)

[Photo credits](https://community.devexpress.com/blogs/markmiller/)
